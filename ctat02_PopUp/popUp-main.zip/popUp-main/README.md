# popUp
Responsive pop up for the website. HTML, CSS, Bootstrap and JavaScript is used to develop it.
